// Code goes here

// to confirm that key listener is working



function soundCheck(sc) {
  const audio = document.querySelector(`audio[data-key="${sc.keyCode}"]`);
  const key = document.querySelector(`.key[data-key="${sc.keyCode}"]`)
  if(!audio) return; // stop the function from running
  audio.currentTime = 0; // allows you to play the same sound over and over without delay
  audio.play();

  key.classList.add('playing');
}

function removeTransition(rt) {
  if (rt.propertyName !== 'transform') return;
  this.classList.remove('playing');
}

const keys = document.querySelectorAll('.key');
keys.forEach(key => key.addEventListener('transitionend', removeTransition));
window.addEventListener('keydown', soundCheck); 